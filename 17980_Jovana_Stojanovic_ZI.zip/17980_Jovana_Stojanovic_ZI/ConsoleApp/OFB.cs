﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Security.Cryptography;
using System.IO;
using static CryptoClasses.Methods;

namespace CryptoClasses
{
    public class OFB
    {
        public static byte[] IVGenerator(int lenght)
        {
            Random rnd = new Random();
            byte[] iv = new byte[lenght];
            rnd.NextBytes(iv);
            //foreach (byte b in iv)
                //Console.WriteLine(b);
            return iv;
        }

        public static string Encrypt(byte[] key, string data, byte[] iv)
        {
            byte[] bData = Encoding.ASCII.GetBytes(data);
            int size = bData.Length;
            if (size % 8 != 0) //da bismo dobili celi broj za broj rundi
                bData = ExtendData(bData);

            size = bData.Length;
            byte[] result = new byte[0];

            for (int i=0; i<size; i+=8)
            {
                iv = DESEncrypt(key, iv); 
                byte[] msgBlock = new byte[8];
                Array.Copy(bData, i, msgBlock, 0, 8);
                byte[] cypherBlock = Methods.xor(msgBlock, iv);

                result = result.Concat(cypherBlock).ToArray();  
            }
           
            string resultStr = Convert.ToBase64String(result);
            return resultStr;
        }

        public static string Decrypt(byte[] key, string data, byte[] iv)
        {
            byte[] bData = Convert.FromBase64String(data);
            int size = bData.Length;

            byte[] result = new byte[0]; 
            for (int i = 0; i < size; i += 8)
            {
                iv = DESEncrypt(key, iv); 
                byte[] msgBlock = new byte[8];
                Array.Copy(bData, i, msgBlock, 0, 8);
                byte[] cypherBlock = Methods.xor(msgBlock, iv);

                result = result.Concat(cypherBlock).ToArray();
            }

            byte[] cutResult = CutData(result);
            string resultStr = Encoding.UTF8.GetString(cutResult);
            return resultStr;
        }

        public static byte[] ExtendData(byte[] bData)
        {
            int size = bData.Length;
            int n = 8 - (size % 8);
            int resultSize = n + size;
            byte[] result = new byte[resultSize];
            Array.Copy(bData, result, size);
            for (int i = size; i < resultSize; i++)
                result[i] = 0;
            return result;
        }

        public static byte[] CutData(byte[] bData)
        {
            int size = bData.Length;
            int n = size - 1;
            while (n >= 0 && bData[n] == 0)
                n--;
            byte[] result = new byte[n + 1];
            Array.Copy(bData, result, n + 1);
            return result;
        }

        public static byte[] DESEncrypt(byte[] key, byte[] iv)
        {
            int size = iv.Length;
            DESCryptoServiceProvider des = new DESCryptoServiceProvider();
            ICryptoTransform encryptor = des.CreateEncryptor(key, iv);
            byte[] result = encryptor.TransformFinalBlock(iv, 0, size);
            return result;
        }
    }
}
