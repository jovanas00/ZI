﻿using System;
using static CryptoClasses.One_time_pad;
using static CryptoClasses.Foursquare_cipher;
using static CryptoClasses.XXTEA;
using static CryptoClasses.OFB;
using static CryptoClasses.Methods;
using static CryptoClasses.SHA1;
using System.Text;

namespace CryptoClasses
{

    class Program
    {
        static void Main(string[] args)
        {
            //One-time-pad
            //byte[] encriptedOTP = One_time_pad.EncryptOrDecrypt("keyOTP.bin", "dataOTP.bin");
            //Methods.WriteInBinaryFile("encriptedOTP.bin", encriptedOTP);
            //Console.WriteLine("Nakon kriptovanja koriscenjem algoritma One-time-pad dobili smo: " + string.Join("", Encoding.ASCII.GetChars(encriptedOTP)));
            //byte[] decriptedOTP = One_time_pad.EncryptOrDecrypt("keyOTP.bin", "encriptedOTP.bin");
            //Console.WriteLine("Nakon kriptovanja koriscenjem algoritma One-time-pad dobili smo: " + string.Join("", Encoding.ASCII.GetChars(decriptedOTP)) + "\n");

            //Foursquare_cipher
            //string plaintText = new string(Methods.ReadFromTextFile("plainTextFSC.txt"));
            //string cypherKey1 = new string(Methods.ReadFromTextFile("cypherKey1FSC.txt"));
            //string cypherKey2 = new string(Methods.ReadFromTextFile("cypherKey2FSC.txt"));

            //string result = Foursquare_cipher.Encrypt(plaintText, cypherKey1, cypherKey2);
            //Methods.WriteInTextFile("foursquare_cipher.txt", result.ToCharArray());

            //string encripted = new string(Methods.ReadFromTextFile("foursquare_cipher.txt"));
            //Console.WriteLine("Nakon kriptovanja koriscenjem algoritma Foursquare cypher dobili smo: " + encripted);
            //string decripted = Foursquare_cipher.Decrypt(encripted);
            //Console.WriteLine("Nakon dekriptovanja koriscenjem algoritma Foursquare cypher dobili smo: " + decripted + "\n");

            //XXTEA
            //string key = new string(Methods.ReadFromTextFile("keyXXTEA.txt"));
            //string data = new string(Methods.ReadFromTextFile("dataXXTEA.txt"));
            //byte[] bKey = Encoding.ASCII.GetBytes(key);
            //byte[] bData = Encoding.ASCII.GetBytes(data);
            //byte[] encriptedXXTEA = XXTEA.Encrypt(bKey, bData);
            //for (int i = 0; i < encriptedXXTEA.Length; i++)
            //Console.WriteLine(string.Join("", encriptedXXTEA));
            //char[] secret = Methods.UIntArrayToCharArray(encriptedXXTEA);
            //Methods.WriteInTextFile("encriptedXXTEA.txt", string.Join("", encriptedXXTEA).ToCharArray());
            //Methods.WriteInTextFile("encriptedXXTEA.txt", Convert.ToBase64String(encriptedXXTEA).ToCharArray());
            //string encrypted = new string(Methods.ReadFromTextFile("encriptedXXTEA.txt"));
            //byte[] decriptedXXTEA = XXTEA.Decrypt(bKey, Convert.FromBase64String(encrypted).ToArray());
            //byte[] decriptedXXTEA = XXTEA.Decrypt(bKey, encriptedXXTEA);

            //Console.WriteLine(Encoding.ASCII.GetChars(decriptedXXTEA));

            //byte[] decriptedXXTEA = XXTEA.Decrypt(bKey, encriptedXXTEA);
            //Console.WriteLine(Encoding.ASCII.GetChars(decriptedXXTEA));
            //char[] secret = Methods.UIntArrayToCharArray(decriptedXXTEA);
            //Console.WriteLine(string.Join(",", secret));
            //Console.WriteLine(string.Join("", decriptedXXTEA));

            //OFB
            //byte[] iv = OFB.IVGenerator(8);
            //Methods.WriteInBinaryFile("ivOFB.bin", iv);
            //byte[] key = OFB.IVGenerator(8);
            //Methods.WriteInBinaryFile("keyOFB.bin", key);
            //string text = new string(Methods.ReadFromTextFile("plainTextOFB.txt"));
            ////kriptovanje
            //string encriptedOFB = OFB.Encrypt(key, text, iv);
            //Methods.WriteInTextFile("encriptedOFB.txt", encriptedOFB.ToCharArray());
            ////dekriptovanje
            //Methods.ReadFromTextFile("encriptedOFB.txt");
            //string decriptedOFB = OFB.Decrypt(key, encriptedOFB, iv);
            ////Console.OutputEncoding = Encoding.UTF8;
            //Console.WriteLine("Nakon kriptovanja koriscenjem algoritma OFB dobili smo: " + encriptedOFB);
            //Console.WriteLine("Nakon dekriptovanja koriscenjem algoritma OFB dobili smo: " + decriptedOFB + "\n");

            ////bmp
            //iv = OFB.IVGenerator(8);
            //key = OFB.IVGenerator(8);
            //byte[] imageData = Methods.ReadFromBMP("slika.bmp");
            //int n = imageData.Length;
            //int w = (int)imageData[n - 2];
            //int h = (int)imageData[n - 1];
            //Array.Copy(imageData, imageData, n-2);
            //string resultStr = Encoding.UTF8.GetString(imageData);
            //string encriptedImage = OFB.Encrypt(key, resultStr, iv);
            //byte[] image = Encoding.ASCII.GetBytes(encriptedImage);
            //Methods.CreateBMP("kriptovanaSlika.bmp", image, w, h);

            ////SHA1
            ////byte[] message = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
            ////byte[] bytes = SHA1.ExtendMessage(message);
            ////for(int i=0; i<bytes.Length; i++)
            ////    Console.Write(bytes[i]);

            //string message = "Hello World";
            //byte[] messageBytes = Encoding.UTF8.GetBytes(message);
            //byte[] hashBytes = SHA1.HashMethod(messageBytes);
            //string hash = BitConverter.ToString(hashBytes).Replace("-", "");
            //Console.WriteLine(hash);
        }
    }
}