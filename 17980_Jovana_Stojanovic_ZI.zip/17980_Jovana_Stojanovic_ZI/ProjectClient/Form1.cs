﻿using ProjectClient.ProjectServiceReference;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectClient
{
    public partial class Form1 : Form
    {
        Service1Client proxy;
        public Form1()
        {
            InitializeComponent();
            proxy = new Service1Client();
        }

        private void buttonEncrypt_Click(object sender, EventArgs e)
        {
            string algorithm = cbxAlgorithm.SelectedItem.ToString();
            if (algorithm == null)
                MessageBox.Show("Niste izabrali algoritam!");
            buttonClearText_Click(sender, e);

            if (algorithm == "One-time pad")
            {
                byte[] encriptedOTP = proxy.Encrypt("dataOTP.bin", "keyOTP.bin", "One-time pad");
                txtPlainText.Text = string.Join("", CryptoClasses.Methods.ReadFromBinaryFile("dataOTP.bin"));
                txtEncryptedText.Text = string.Join("", encriptedOTP);
                CryptoClasses.Methods.WriteInBinaryFile("encriptedOTP.bin", encriptedOTP);
            }
            if (algorithm == "Foursquare cipher")
            {
                string plaintText = new string(CryptoClasses.Methods.ReadFromTextFile("plainTextFSC.txt"));
                txtPlainText.Text = plaintText;
                string cypherKey1 = new string(CryptoClasses.Methods.ReadFromTextFile("cypherKey1FSC.txt"));
                byte[] result = proxy.Encrypt(plaintText, cypherKey1, "Foursquare cipher");
                txtEncryptedText.Text = Convert.ToBase64String(result);
                CryptoClasses.Methods.WriteInTextFile("foursquare_cipher.txt", Encoding.UTF8.GetChars(result));

            }
            if (algorithm == "XXTEA")
            {
                string key = new string(CryptoClasses.Methods.ReadFromTextFile("keyXXTEA.txt"));
                string plainText = new string(CryptoClasses.Methods.ReadFromTextFile("dataXXTEA.txt"));
                txtPlainText.Text = plainText;
                byte[] encriptedXXTEA = proxy.Encrypt(plainText, key, "XXTEA");
                txtEncryptedText.Text = string.Join("", encriptedXXTEA);
                CryptoClasses.Methods.WriteInTextFile("encriptedXXTEA.txt", Convert.ToBase64String(encriptedXXTEA).ToCharArray());
            }
            if (algorithm == "OFB")
            {
                string text = new string(CryptoClasses.Methods.ReadFromTextFile("plainTextOFB.txt"));
                txtPlainText.Text = text;
                byte[] encriptedOFB = proxy.Encrypt(text, null, "OFB");
                string encryptedText = Encoding.ASCII.GetString(encriptedOFB);
                txtEncryptedText.Text = encryptedText;
                CryptoClasses.Methods.WriteInTextFile("encriptedOFB.txt", encryptedText.ToCharArray());
            }
        }

        private void buttonDecrypt_Click(object sender, EventArgs e)
        {
            string algorithm = cbxAlgorithm.SelectedItem.ToString();
            if (algorithm == null)
                MessageBox.Show("Niste izabrali algoritam!");

            if (algorithm == "One-time pad")
            {
                byte[] decriptedOTP = proxy.Decrypt("encriptedOTP.bin", "keyOTP.bin", "One-time pad");
                txtDecryptedText.Text = string.Join("", decriptedOTP);
                CryptoClasses.Methods.WriteInBinaryFile("decriptedOTP.bin", decriptedOTP);
            }
            if(algorithm == "Foursquare cipher") 
            {
                string encripted = new string(CryptoClasses.Methods.ReadFromTextFile("foursquare_cipher.txt"));
                byte[] decripted = proxy.Decrypt(encripted, null, "Foursquare cipher");
                CryptoClasses.Methods.WriteInTextFile("decriptedFSC.txt", Encoding.UTF8.GetChars(decripted));
                txtDecryptedText.Text = string.Join("", Encoding.UTF8.GetChars(decripted));
            }
            if(algorithm == "XXTEA")
            {
                string key = new string(CryptoClasses.Methods.ReadFromTextFile("keyXXTEA.txt"));
                string encriptedText = new string(CryptoClasses.Methods.ReadFromTextFile("encriptedXXTEA.txt"));
                byte[]  decriptedXXTEA = proxy.Decrypt(encriptedText, key, "XXTEA");
                CryptoClasses.Methods.WriteInTextFile("decriptedXXTEA.txt", Encoding.ASCII.GetChars(decriptedXXTEA));
                txtDecryptedText.Text = string.Join("", Encoding.ASCII.GetChars(decriptedXXTEA));
            }
            if(algorithm == "OFB")
            {
                string text = new string(CryptoClasses.Methods.ReadFromTextFile("encriptedOFB.txt"));
                byte[] decriptedOFB = proxy.Decrypt(text, null, "OFB");
                string decripted = Encoding.ASCII.GetString(decriptedOFB);
                CryptoClasses.Methods.WriteInTextFile("decriptedOFB.txt", decripted.ToCharArray());
                txtDecryptedText.Text = decripted;
            }

            //provera hash vrednosti
            byte[] originalText = Encoding.UTF8.GetBytes(txtPlainText.Text);
            byte[] decryptedText = Encoding.UTF8.GetBytes(txtDecryptedText.Text);
            bool check = proxy.CompareFiles(originalText, decryptedText);

            if (check)
                txtHashValue.Text = "Originalni i dekriptovani fajl su isti.";
            else
                txtHashValue.Text = "Originalni i dekriptovani fajl nisu isti.";
        }

        private void buttonClearText_Click(object sender, EventArgs e)
        {
            txtPlainText.Clear();
            txtEncryptedText.Clear();
            txtDecryptedText.Clear();
            txtHashValue.Clear();
        }

        //metoda koja poziva metodu za kreiranje bmp slike
        private void buttonUploadFile_Click(object sender, EventArgs e)
        {
            byte[] image = proxy.Encrypt("slika.bmp", "kriptovanaSlika.bmp", "Image");
            if (image != null)
                txtHashValue.Text = "Slika je kreirana(Files\\kriptovanaSlika.bmp).";
            else
                txtHashValue.Text = "Slika nije kreirana";
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
