﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Activation;
using System.ServiceModel.Web;
using System.Text;
using CryptoClasses;

namespace ProjectService
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service1" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select Service1.svc or Service1.svc.cs at the Solution Explorer and start debugging.
    [ServiceBehavior(InstanceContextMode = InstanceContextMode.PerCall)]
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Required)]
    public class Service1 : IService1
    {

        public byte[] Encrypt(string plainText, string key, string algorithm)
        {
            switch (algorithm)
            {
                case "One-time pad":
                    return CryptoClasses.One_time_pad.EncryptOrDecrypt(key, plainText);
                case "Foursquare cipher":
                    string cypherKey2 = new string(Methods.ReadFromTextFile("cypherKey2FSC.txt"));
                    string result = Foursquare_cipher.Encrypt(plainText, key, cypherKey2);
                    byte[] bData = Encoding.ASCII.GetBytes(result);
                    return bData;
                case "XXTEA":
                    byte[] bKey = Encoding.ASCII.GetBytes(key);
                    byte[] bText = Encoding.ASCII.GetBytes(plainText);
                    return CryptoClasses.XXTEA.Encrypt(bKey, bText);
                case "OFB":
                    byte[] iv = CryptoClasses.OFB.IVGenerator(8);
                    CryptoClasses.Methods.WriteInBinaryFile("ivOFB.bin", iv);
                    byte[] keyOFB = CryptoClasses.OFB.IVGenerator(8);
                    CryptoClasses.Methods.WriteInBinaryFile("keyOFB.bin", keyOFB);
                    return Encoding.ASCII.GetBytes(CryptoClasses.OFB.Encrypt(keyOFB, plainText, iv));
                case "Image":
                    byte[] ivImg = CryptoClasses.OFB.IVGenerator(8);
                    CryptoClasses.Methods.WriteInBinaryFile("ivImg.bin", ivImg);
                    byte[] keyImg = CryptoClasses.OFB.IVGenerator(8);
                    CryptoClasses.Methods.WriteInBinaryFile("keyImg.bin", keyImg);
                    byte[] imageData = Methods.ReadFromBMP(plainText);
                    int n = imageData.Length;
                    int w = (int)imageData[n - 2];
                    int h = (int)imageData[n - 1];
                    Array.Copy(imageData, imageData, n - 2);
                    string resultStr = Encoding.UTF8.GetString(imageData);
                    string encriptedImage = OFB.Encrypt(keyImg, resultStr, ivImg);
                    byte[] image = Encoding.ASCII.GetBytes(encriptedImage);
                    CryptoClasses.Methods.CreateBMP(key, image, w, h);
                    return image;
                default:
                    throw new ArgumentException("Izabrali ste navelidan algoritam.");
            }
        }

        public byte[] Decrypt(string encriptedText, string key, string algorithm)
        {
            switch(algorithm)
            {
                case "One-time pad":
                    return CryptoClasses.One_time_pad.EncryptOrDecrypt(key, encriptedText);
                case "Foursquare cipher":
                    string decripted = Foursquare_cipher.Decrypt(encriptedText);
                    byte[] bData = Encoding.UTF8.GetBytes(decripted);
                    return bData;
                case "XXTEA":
                    byte[] bKey = Encoding.ASCII.GetBytes(key);
                    byte[] bText = Convert.FromBase64String(encriptedText).ToArray();
                    return CryptoClasses.XXTEA.Decrypt(bKey, bText);
                case "OFB":
                    byte[] iv = CryptoClasses.Methods.ReadFromBinaryFile("ivOFB.bin");
                    byte[] keyOFB = CryptoClasses.Methods.ReadFromBinaryFile("keyOFB.bin");
                    return Encoding.ASCII.GetBytes(CryptoClasses.OFB.Decrypt(keyOFB, encriptedText, iv));
                default:
                    throw new ArgumentException("Izabrali ste nevalidan algoritam.");
            }
        }

        public bool CompareFiles(byte[] originalText, byte[] decryptedText)
        {
            byte[] originalHash = CryptoClasses.SHA1.HashMethod(originalText);
            byte[] decriptedHash = CryptoClasses.SHA1.HashMethod(decryptedText);

            return originalHash.SequenceEqual(decriptedHash);
        }
    }
}
