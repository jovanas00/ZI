﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZIProjekat_in_Csharp
{
    class Foursquare_cipher
    {

        private static char[,] topLeft = new char[5, 5];
        private static char[,] topRight = new char[5, 5];
        private static char[,] bottomLeft = new char[5, 5];
        private static char[,] bottomRight = new char[5, 5];
        private static string keyRight;
        private static string keyLeft;

        //rezultutjuca matrica
        private static char[,] result = new char[10, 10];

        public static string Encrypt(string plainText, string cypherKey1, string cypherKey2)
        {

            //gornja leva i donja desna matrica se popunjavaju karakterima samo 
            int ascii = 64; //uzimamo velika slova
            for (int i = 0; i < 5; i++)
                for (int j = 0; j < 5; j++)
                {
                    ascii++;
                    if (ascii == 74)  //slovo j se preskace
                        ascii++;
                    topLeft[i, j] = (char)ascii;
                    bottomRight[i, j] = (char)ascii;
                }

            string[] keys = new string[2];
            keyRight = keys[0];
            keyLeft = keys[1];
            keys = GenerateKey(cypherKey1, cypherKey2);

            //popunjavamo gornju desnu
            int n = -1;
            for (int i = 0; i < 5; i++)
                for (int j = 0; j < 5; j++)
                {
                    n++;
                    topRight[i, j] = keys[0][n];
                }
            
            //popunjavamo gornju levu
            n = -1;
            for (int i = 0; i < 5; i++)
                for (int j = 0; j < 5; j++)
                {
                    n++;
                    bottomLeft[i, j] = keys[1][n];
                }


            string polja = new string("");//promenljiva u kojoj smestamo vrednosti koje ce ciniti polja rezultujuce matrice
            for (int i = 0; i < 5; i++)
                for (int j = 0; j < 10; j++)
                {
                    if (j > 4)
                    {
                        int k = j - 5;
                        polja = polja + topRight[i, k];
                    }
                    else
                    {
                        polja = polja + topLeft[i, j];
                    }
                }
            for (int i = 0; i < 5; i++)
                for (int j = 0; j < 10; j++)
                {
                    if (j > 4)
                    {
                        int k = j - 5;
                        polja = polja + bottomRight[i, k];
                    }
                    else
                    {
                        polja = polja + bottomLeft[i, j];
                    }
                }
            n = -1; //indeks za kretanje kroz string polja
            //punimo rezultujucu matricu vrednostima iz stringa polja
            for (int i = 0; i < 10; i++)
                for (int j = 0; j < 10; j++)
                {
                    n++;
                    result[i, j] = polja[n];
                }

            string encripted = new string("");
            for (int i = 0; i < plainText.Length; i += 2)
            {
                int red = 0;
                int kolona = 0;
                for (int j = 0; j < 5; j++)
                    for (int k = 0; k < 5; k++)
                    {
                        if (topLeft[j, k] == plainText[i])
                        {
                            red = j;
                            break;
                        }
                        if (red != 0)
                            break;
                    }
                for (int j = 0; j < 5; j++)
                    for (int k = 0; k < 5; k++)
                    {
                        if (bottomRight[j, k] == plainText[i + 1])
                        {
                            kolona = k + 5;
                            break;
                        }
                        if (kolona != 0)
                            break;
                    }
                encripted = encripted + Char.ToString(result[red, kolona]);

                red = 0;
                kolona = 0;
                for (int j = 0; j < 5; j++)
                    for (int k = 0; k < 5; k++)
                    {
                        if (bottomRight[j, k] == plainText[i + 1])
                        {
                            red = j + 5;
                            break;
                        }
                        if (red != 0)
                            break;
                    }
                for (int j = 0; j < 5; j++)
                    for (int k = 0; k < 5; k++)
                    {
                        if (topLeft[j, k] == plainText[i])
                        {
                            kolona = k;
                            break;
                        }
                        if (kolona != 0)
                            break;
                    }
                encripted = encripted + Char.ToString(result[red, kolona]);
            }

            return encripted;
        }

        public static string Decrypt(string encripted)
        {
            string decripted = new string("");
            int length = encripted.Length;
            for(int i=0; i<length; i+=2)
            {
                int red = 0;
                int kolona = 0;
                for(int j=0; j<5; j++)
                    for(int k=0; k<5; k++)
                    {
                        if(topRight[j,k] == encripted[i])
                        {
                            red = j;
                            break;
                        }
                        if (red != 0)
                            break;
                    }
                for (int j = 0; j < 5; j++)
                    for (int k = 0; k < 5; k++)
                    {
                        if (bottomLeft[j, k] == encripted[i+1])
                        {
                            kolona = k;
                            break;
                        }
                        if (kolona != 0)
                            break;
                    }
                decripted = decripted + Char.ToString(result[red, kolona]);

                red = 0;
                kolona = 0;
                for (int j = 0; j < 5; j++)
                    for (int k = 0; k < 5; k++)
                    {
                        if (bottomLeft[j, k] == encripted[i+1])
                        {
                            red = j+5;
                            break;
                        }
                        if (red != 0)
                            break;
                    }
                for (int j = 0; j < 5; j++)
                    for (int k = 0; k < 5; k++)
                    {
                        if (topRight[j, k] == encripted[i])
                        {
                            kolona = k+5;
                            break;
                        }
                        if (kolona != 0)
                            break;
                    }
                decripted = decripted + Char.ToString(result[red, kolona]);
            }

            return decripted;
        }

        public static string [] GenerateKey(string key1, string key2)
        {
            string [] keys = new string[2] { "", "" }; 

            //pravimo kljuceve od slova prosledjenih, pritom ne racunamo duplikate
            for (int i=0; i<key1.Length; i++)
            {
                char c = key1[i];
                if(!keys[0].Contains(c))
                    keys[0] += c;
            }
            for (int i=0; i<key2.Length; i++)
            {
                char c = key2[i];
                if (!keys[0].Contains(c) && !keys[1].Contains(c))
                    keys[1] += c;
            }

            //dodajemo ostala slova alfabeta
            for(char c = 'A'; c<='Z'; c++)
            {
                if (!keys[0].Contains(c))
                    keys[0] += c;
                if (!keys[1].Contains(c))
                    keys[1] += c;
            }

            return keys;
        }
    }
}
