﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Xml.Serialization;
using System.Drawing;
using System.Drawing.Imaging;

namespace ZIProjekat_in_Csharp
{
    class Methods
    {
        public static byte[] xor(byte[] left, byte[] right)
        {
            byte[] val = new byte[left.Length];
            for (int i = 0; i < left.Length; i++)
                val[i] = (byte)(left[i] ^ right[i]);
            return val;
        }

        //?
        public static void Serialize(object obj, string fileName)
        {
            Type objType = obj.GetType();
            XmlSerializer sr = new XmlSerializer(objType);

            TextWriter wr = new StreamWriter(fileName);

            sr.Serialize(wr, obj);
            wr.Close();

        }


        //?
        public static object Deserialize(string fileName, Type t)
        {
            XmlSerializer sr = new XmlSerializer(t);
            FileStream fs = new FileStream(fileName, FileMode.Open);
            TextReader reader = new StreamReader(fs);
            return sr.Deserialize(reader);

        }

        //Metoda za ucitavanje niza karaktera iz fajla
        public static char[] ReadFromTextFile(string path)
        {
            StreamReader sr = new StreamReader(path);
            long length = sr.BaseStream.Length;
            char[] text = new char[length];
            for (int i = 0; i < length; i++)
                text[i] = (char)sr.Read();
            sr.Close();
            return text;
        }

        //Metoda za upis niza karaktera u fajl
        public static void WriteInTextFile(string path, char[] text)
        {
            StreamWriter sw = new StreamWriter(path);
            foreach (char c in text)
            {
                sw.Write(c);
            }
            sw.Close();
        }

        //Metoda za ucitavanje niza bitova iz fajla
        public static byte[] ReadFromBinaryFile(string path)
        {
            FileStream fs = new FileStream(path, FileMode.Open);
            int length = (int)fs.Length;
            byte[] text = new byte[length];
            for (int i = 0; i < length; i++)
                text[i] = (byte)fs.ReadByte();
            fs.Close();
            return text;
        }

        //Metoda za upis niza bitova u fajl
        public static void WriteInBinaryFile(string path, byte[] text)
        {
            FileStream fs = new FileStream(path, FileMode.Open);
            foreach (byte b in text)
                fs.WriteByte(b);
            fs.Close();
        }

        //Metoda za ucitavanje podataka iz BMP 24-bit slika
        public static byte[] ReadFromBMP(string path)
        {
            FileStream fs = new FileStream(path, FileMode.Open);
            Bitmap bmp = new Bitmap(fs);
            int h = bmp.Height;
            int w = bmp.Width;
            int size = h * w * 3 + 2;  //2 dodata bajta su da se vrate dimenzije slike, kako bi posle mogla da se napravi nova kriptovana slika
            byte[] result = new byte[size];
            int k = 0;
            for (int i = 0; i < h; i++)
                for (int j = 0; j < w; j++)
                {
                    Color pixel = bmp.GetPixel(i, j); //uzimamo boje pixela
                    result[k++] = pixel.B;
                    result[k++] = pixel.G;
                    result[k++] = pixel.R;
                }
            result[k++] = (byte)w;
            result[k++] = (byte)h;
            fs.Close();
            return result;
        }

        //Metoda za kreiranje 24-bit BMP slike
        public static void CreateBMP(string path, byte[] image, int w, int h)
        {
            Bitmap bmp = new Bitmap(w, h, PixelFormat.Format24bppRgb);
            int k = 0;
            for (int i = 0; i < h; i++)
                for (int j = 0; j < w; j++)
                {
                    byte b = image[k++];
                    byte g = image[k++];
                    byte r = image[k++];
                    Color pixel = Color.FromArgb(r, g, b);
                    bmp.SetPixel(i, j, pixel);
                }
            bmp.Save(path);
        }

        //??
        public static uint[] CharArrayToUIntArray(char[] data)
        {
            int length = data.Length;
            uint[] result = new uint[length];
            for (int i = 0; i < length; i++)
            {
                char data1 = data[i];
                String str = data1.ToString();//.ToString());
                result[i] = uint.Parse(str);
            }
            return result;
        }

        //??
        public static char[] UIntArrayToCharArray(uint[] data)
        {
            int length = data.Length;
            char[] result = new char[length];
            for (int i = 0; i < length; i++)
                result[i] = (char)data[i];
            return result;
        }
    }
}
