﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using static ZIProjekat_in_Csharp.Methods;
//using System.Text;

namespace ZIProjekat_in_Csharp
{
    class One_time_pad
    {    
        public static byte[] GenerateKey(byte[] initialKey)
        {
            int length = initialKey.Length;
            int bit = initialKey[0];
            for (int i = 0; i < length - 1; i++)
                initialKey[i] = initialKey[i + 1];
            initialKey[length - 1] = (byte)(initialKey[length - 2] ^ initialKey[length - 3]);
            return initialKey;
        }
       
        //za kriptovanje i dekriptovanje ce biti iskoriscen isti kod i kljuc samo ce biti promenjen podatak
        public static byte[] EncryptOrDecrypt(string keyPath, string dataPath)//byte[] data, byte[] pad)
        {
            byte[] key = Methods.ReadFromBinaryFile(keyPath);
            byte[] data = Methods.ReadFromBinaryFile(dataPath);

            int lKey = key.Length;
            int lData = data.Length;

            byte[] cutKey = new byte[lData];
            byte[] cutData = new byte[lData];
            byte[] result = new byte[lData];
            if (lKey < lData) //kljuc kraci od podatka
            {
                cutData = data;
                cutKey = key;
                for (int i=0; i<lData; i++)
                    for(int j=0; j<lKey; j++)
                    {
                        result[i] = (byte)(cutData[i] ^ cutKey[j]);
                        cutKey = GenerateKey(cutKey);
                    }
                return result;              
            }
            else if (lKey > lData) //podatak kraci od kljuca
            {
                Array.Copy(key, 0, cutKey, 0, lData);

                cutData = data;
                for(int i=0; i<cutKey.Length;i++)
                    Console.WriteLine("Nov podatak: " + cutKey[i]);
            }
            else //ako su iste duzine ne vrsi se modifikacija
            {
                cutKey = key;
                cutData = data;
            }

            result = Methods.xor(cutData, cutKey); // xor izmedju kljuca i podatka
            return result;
        }
    }
}
