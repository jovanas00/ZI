﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZIProjekat_in_Csharp
{
    class SHA1
    {
        public static byte[] HashMethod(byte[] message) //uint[] niz 32bitnih vrednosti
        {
            //inicijalne promenljive
            uint h0 = 0x67452301;
            uint h1 = 0xEFCDAB89;
            uint h2 = 0x98BADCFE;
            uint h3 = 0x10325476;
            uint h4 = 0xC3D2E1F0;

            int n = message.Length; //duzina originalne poruke

            byte[] extendedMsg = ExtendMessage(message);
            int t = extendedMsg.Length / 64; //512/8 = 64, jer su ovde bajtovi 

            //BitArray bits = new BitArray(extendedMsg);
            List<byte[]> blocks = SplitIntoBlocks(extendedMsg);

            for(int i=0; i<t; i++)
            {
                //podelimo blokove od 512bita na n=16 size=32bitna - 64bajta=n=16*size=4bajta
                uint[] w = new uint[80];
                
                //fali ona for petlja
                for (int j = 0; i < 16; i++)
                    w[i] = BitConverter.ToUInt32(blocks[j], j*4); //16 bloka po 32bita(uint)

                for (int j = 16; j < 80; j++)
                    w[j] = LeftRotate(w[j-3]^w[j-8]^w[j-14]^w[j-16], 1);

                //
                uint a = h0;
                uint b = h1;
                uint c = h2;
                uint d = h3;
                uint e = h4;

                for(int j=0; j<80; j++)
                {
                    uint f = 0; //funkcija f
                    uint k = 0; //kljuc k
                    if (j <= 19)
                    {
                        f = (b & c) ^ ((~b) & d);
                        k = 0x5A827999;
                    }
                    if(j<=39)
                    {
                        f = b ^ c ^ d;
                        k = 0x6ED9EBA1;
                    }
                    if(j<=59)
                    {
                        f = (b & c) | (b & d) | (c & d);
                        k = 0x8F1BBCDC;
                    }
                    if(j<=79)
                    {
                        f = b ^ c ^ d;
                        k = 0xCA62C1D6;
                    }

                    uint temp = LeftRotate(a, 5) + f + e + k + w[j];
                    e = d;
                    d = c;
                    c = LeftRotate(b, 30);
                    b = a;
                    a = temp;
                }

                h0 = h0 + a;
                h1 = h1 + b;
                h2 = h2 + c;
                h3 = h3 + d;
                h4 = h4 + e;
            }

            byte[] result = new byte[20];
            Array.Copy(BitConverter.GetBytes(h0), 0, result, 0, 4);
            Array.Copy(BitConverter.GetBytes(h1), 0, result, 4, 4);
            Array.Copy(BitConverter.GetBytes(h2), 0, result, 8, 4);
            Array.Copy(BitConverter.GetBytes(h3), 0, result, 12, 4);
            Array.Copy(BitConverter.GetBytes(h4), 0, result, 16, 4);

            return result;
        }

        public static byte[] ExtendMessage(byte[] message)
        {
            //int n = message.Length; //originalna dužina 
            BitArray bits = new BitArray(message);
            int n = bits.Length; //originalna duzina

            int n1 = n;
            n1++; //duzina poruke nakon dodavanja jedinice
            bits.Length = n1;
            bits[n1 - 1] = true; //dodajemo jedan bit '1' na poruku

            //stara duzina je n1 

            int k = 448 - (n1 % 512);
            if (k < 0)
                k += 512;

            int n2 = n + k; //duzina poruke nakon dodavanja nula
            bits.Length = n2;
            for (int i = 0; i < k; i++)
                bits[n1 + i - 1] = false; //dodajemo k '0' na poruku

            //dodavanje originalne duzine u big-endian formatu
            byte[] b = BitConverter.GetBytes(n); //pretvorimo n u byte[]
            Array.Resize(ref b, 8); //treba da bude 64bitna vr
            if (BitConverter.IsLittleEndian) //ako je little-endian pretvaramo u big-endian
                Array.Reverse(b);
            BitArray lbits = new BitArray(b); //da bismo mogli da dodamo bitove na kraj poruke
            int n3 = lbits.Length;
            int n4 = n2 + n3; //duzina poruke na kraju
            bits.Length = n4;
            for (int i = 0; i < n3; i++)
                bits[n2 + i - 1] = lbits[i];

            //poruka se opet convertuje u byte[]
            message = new byte[(bits.Length + 7) / 8];
            bits.CopyTo(message, 0);
            return message;
        }

        private static List<byte[]> SplitIntoBlocks(byte[] message)
        {
            int length = message.Length;
            List<byte[]> blocks = new List<byte[]>();
            for (int i=0; i<length; i+=64)
            {
                blocks.Add(message.Skip(i).Take(64).ToArray());
            }
            return blocks;
        }
        
        public static uint LeftRotate(uint value, int n)
        {
            return value << n | (value >> (32 - n));
        }
    }
}
