﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static ZIProjekat_in_Csharp.Methods;

namespace ZIProjekat_in_Csharp
{
    class XXTEA
    {
        private static uint delta = 0x9e3779b9;  //32bita su const vrednost-velicina blokova

        public static byte[] Encrypt(byte[] bkey, byte[] bdata)
        {
            int lData = bdata.Length;
            int lKey = bkey.Length;
            if (lData == 0)
                return bdata;
            bdata = ExtendData(bkey, 16);
            bdata = ExtendData(bdata, 16);
            uint[] ukey = new uint[lKey / 4];
            uint[] udata = new uint[lData / 4];
            for(int i=0; i<ukey.Length; i++)
                ukey[i] = BitConverter.ToUInt32(bkey, i*4);
            for (int i = 0; i < udata.Length; i++)
                udata[i] = BitConverter.ToUInt32(bdata, i * 4);
            uint[] uresult = XXTEA.EncryptWithUInt(ukey, udata);
            byte[] bresult = new byte[uresult.Length * 4];
            for(int i=0; i<uresult.Length; i++)
            {
                byte[] pom = BitConverter.GetBytes(uresult[i]);
                pom.CopyTo(bresult, i * 4);
            }
            return bresult;
        }

        public static byte[] Decrypt(byte[] bkey, byte[] bdata)
        {
            int lData = bdata.Length;
            int lKey = bkey.Length;
            if (lData == 0)
                return bdata;
            uint[] ukey = new uint[lKey / 4];
            uint[] udata = new uint[lData / 4];
            for (int i = 0; i < ukey.Length; i++)
                ukey[i] = BitConverter.ToUInt32(bkey, i * 4);
            for (int i = 0; i < udata.Length; i++)
                udata[i] = BitConverter.ToUInt32(bdata, i * 4);
            uint[] uresult = XXTEA.DecryptWithUInt(ukey, udata);
            byte[] bresult = new byte[uresult.Length * 4];
            for (int i = 0; i < uresult.Length; i++)
            {
                byte[] pom = BitConverter.GetBytes(uresult[i]);
                pom.CopyTo(bresult, i * 4);
            }
            bresult = CutData(bresult);
            return bresult;
        }
        public static uint[] EncryptWithUInt(uint[] ukey, uint[] udata)//string keyPath, string dataPath)
        {
            //char[] key = Methods.ReadFromTextFile(keyPath);
            //char[] data = Methods.ReadFromTextFile(dataPath);
            //uint[] ukey = Methods.CharArrayToUIntArray(key);
            //uint[] udata = Methods.CharArrayToUIntArray(data);
            int lKey = ukey.Length;
            int lData = udata.Length;
            
            //Console.WriteLine("Key: ");
            //for (int i = 0; i < ukey.Length; i++)
            //    Console.WriteLine(ukey[i]);
            //Console.WriteLine("Key: ");
            //for (int i = 0; i < lData; i++)
            //    Console.WriteLine(udata[i]);

            uint n = (uint)lData - 1;
            uint y = udata[0];
            uint z = udata[n];
            uint s = 0;
            uint p;
            uint q = 6 + 52 / (n + 1);
            uint e;

            if (n < 1)
                return udata;

            if(lKey<4)
            {
                uint[] k = new uint[4];
                ukey.CopyTo(k, 0);
                ukey = k;
            }

            while(0<q--)
            {
                s += delta;
                e = (s >> 2) & 3;
                for(p = 0; p<n; p++)
                {
                    y = udata[p + 1];
                    z = udata[p] += (((z >> 5 ^ y << 2) + (y >> 3 ^ z << 4)) ^ ((s ^ y) + (ukey[p & 3 ^ e] ^ z)));
                }
                y = udata[0];
                z = udata[n] += (((z >> 5 ^ y << 2) + (y >> 3 ^ z << 4)) ^ ((s ^ y) + (ukey[p & 3 ^ e] ^ z)));
            }
            return udata;
        }

        public static uint[] DecryptWithUInt(uint[] ukey, uint[] udata)//string keyPath, string encodedPath)
        {
            //char[] key = Methods.ReadFromTextFile(keyPath);
            //char[] data = Methods.ReadFromTextFile(encodedPath);
            //uint[] ukey = Methods.CharArrayToUIntArray(key);
            //uint[] udata = Methods.CharArrayToUIntArray(data);
            int lKey = ukey.Length;
            int lData = udata.Length;
            //Console.WriteLine("Key: ");
            //for (int i = 0; i < ukey.Length; i++)
            //    Console.WriteLine(ukey[i]);
            //Console.WriteLine("Key: ");
            //for (int i = 0; i < lData; i++)
            //    Console.WriteLine(udata[i]);


            uint n = (uint)lData - 1;
            uint y = udata[0];
            uint z;
            uint p;
            uint q = 6 + 52 / (n + 1);
            uint s = delta * q;
            uint e;

            if (n < 1)
                return udata;

            if (lKey < 4)
            {
                uint[] k = new uint[4];
                ukey.CopyTo(k, 0);
                ukey = k;
            }

            while (s!=0)
            {
                e = (s >> 2) & 3;
                for(p=n; p>0; p--)
                {
                    z = udata[p - 1];
                    y = udata[p] -= (((z >> 5 ^ y << 2) + (y >> 3 ^ z << 4)) ^ ((s ^ y) + (ukey[p & 3 ^ e] ^ z)));
                }
                z = udata[n];
                y = udata[0] -= (((z >> 5 ^ y << 2) + (y >> 3 ^ z << 4)) ^ ((s ^ y) + (ukey[p & 3 ^ e] ^ z)));
                s -= delta;
            }

            return udata;
        }

        public static byte[] ExtendData(byte[] bData, int size)
        {
            int length = bData.Length;
            int n = size - (length % size);
            int resultSize = n + length;
            byte[] result = new byte[resultSize];
            Array.Copy(bData, result, length);
            for (int i = length; i < resultSize; i++)
                result[i] = 0;
            return result;
        }

        public static byte[] CutData(byte[] bData)
        {
            int length = bData.Length;
            int n = length - 1;
            while (n >= 0 && bData[n] == 0)
                n--;
            byte[] result = new byte[n + 1];
            Array.Copy(bData, result, n + 1);
            return result;
        }
    }
}
